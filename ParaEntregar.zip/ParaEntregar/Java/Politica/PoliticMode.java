package Politica;
public enum PoliticMode {
    ROND_ROBIN,
    RANDOM,
    HIGH_PRIO
}
