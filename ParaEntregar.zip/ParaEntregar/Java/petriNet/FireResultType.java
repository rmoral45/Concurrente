package petriNet;

public enum FireResultType {
    SUCCESS,
    RESOURCE_UNAVAILABLE,
    TIME_DISABLED
}
